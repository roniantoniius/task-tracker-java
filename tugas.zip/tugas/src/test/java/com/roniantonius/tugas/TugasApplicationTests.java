package com.roniantonius.tugas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TugasApplicationTests {

	@Test
	void contextLoads() {
	}

}
